// main class to run the chat bot
public class ChatBotUser {
	public static void main(String args[]) {
		ChatBot aliceBot = new ChatBot();
		aliceBot.startConversation();
	}
}
